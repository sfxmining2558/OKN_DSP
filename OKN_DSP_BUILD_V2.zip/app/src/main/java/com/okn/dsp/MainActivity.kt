package com.okn.dsp

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.TextView

class MainActivity: Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  val t=TextView(this)
  t.text="OKN_DSP\nBP1048P4 7CH DSP Controller\n\nUI V2 Base"
  t.textSize=28f
  t.setTextColor(Color.WHITE)
  t.setBackgroundColor(Color.BLACK)
  setContentView(t)
 }
}