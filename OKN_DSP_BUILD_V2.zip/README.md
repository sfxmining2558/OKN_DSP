OKN_DSP BUILD V2

Android APK build project.

Target:
MVSilicon BP1048P4
7 Channel DSP

Next UI:
- Main Mixer
- EQ 15 Band
- Crossover
- Delay
- Preset