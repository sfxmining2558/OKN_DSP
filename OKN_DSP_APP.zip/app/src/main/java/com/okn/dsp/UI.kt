package com.okn.dsp

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun OKNDSPApp(){
 MaterialTheme{
  Text("OKN_DSP\nBP1048P4 7CH DSP")
 }
}
