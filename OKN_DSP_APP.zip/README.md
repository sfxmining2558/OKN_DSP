OKN_DSP BP1048P4 7CH Controller
Upload to GitHub and build with Actions.
