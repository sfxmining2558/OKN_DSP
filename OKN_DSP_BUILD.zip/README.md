OKN_DSP
BP1048P4 7CH DSP Controller

Mobile upload build package.
Upload this file to GitHub and run Actions.

App name:
OKN_DSP

Target:
Android APK