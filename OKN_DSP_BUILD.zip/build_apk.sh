#!/bin/bash
echo "OKN_DSP project generator placeholder"
echo "Next version will include full Jetpack Compose UI"